
	
APP.localStorage = {

init: function(){



console.log('teststore');

}

}
